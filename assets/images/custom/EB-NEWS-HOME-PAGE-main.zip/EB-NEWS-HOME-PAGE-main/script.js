// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initApp();
});

function initApp() {
    // Elements
    const loadingScreen = document.getElementById('loadingScreen');
    const scrollToTopBtn = document.getElementById('scrollToTop');
    const header = document.getElementById('header');
    const navbar = document.getElementById('navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navDropdownToggles = document.querySelectorAll('.nav-dropdown-toggle');
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle.querySelector('i');
    const searchInput = document.getElementById('searchInput');
    const cartBtn = document.getElementById('cartBtn');
    const cartCount = document.querySelector('.cart-count');
    const cartSidebar = document.getElementById('cartSidebar');
    const cartClose = document.getElementById('cartClose');
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    const contactForm = document.getElementById('contactForm');
    const productModal = document.getElementById('productModal');
    const modalClose = document.getElementById('modalClose');
    const modalBody = document.getElementById('modalBody');
    const categoryLinks = document.querySelectorAll('.category-link');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const productsGrid = document.querySelector('.products-grid');
    const statNumbers = document.querySelectorAll('.stat-number');

    // State
    let cart = [];
    let products = [];
    let currentFilter = 'all';
    let isDarkMode = localStorage.getItem('darkMode') === 'true';

    // Initialize
    initializeTheme();
    initializeProducts();
    initializeAnimations();
    initializeCounters();

    // Loading screen
    setTimeout(() => {
        loadingScreen.classList.add('hidden');
    }, 1000);

    // Scroll to top button
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.classList.add('visible');
            header.classList.add('scrolled');
        } else {
            scrollToTopBtn.classList.remove('visible');
            header.classList.remove('scrolled');
        }

        // Update active nav link based on scroll position
        updateActiveNavLink();

        // Trigger animations
        triggerAnimations();
    });

    // Scroll to top functionality
    scrollToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Mobile menu toggle
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }

    // Dropdown menu toggle
    navDropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const parentDropdown = this.closest('.nav-dropdown');
            const isOpen = parentDropdown.classList.contains('open');

            document.querySelectorAll('.nav-dropdown').forEach(dropdown => {
                dropdown.classList.remove('open');
                const dropdownToggle = dropdown.querySelector('.nav-dropdown-toggle');
                if (dropdownToggle) {
                    dropdownToggle.setAttribute('aria-expanded', 'false');
                }
            });

            if (!isOpen) {
                parentDropdown.classList.add('open');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });

    // Close mobile menu when clicking a link
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (hamburger && navMenu) {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            }
            document.querySelectorAll('.nav-dropdown').forEach(dropdown => {
                dropdown.classList.remove('open');
                const dropdownToggle = dropdown.querySelector('.nav-dropdown-toggle');
                if (dropdownToggle) {
                    dropdownToggle.setAttribute('aria-expanded', 'false');
                }
            });

            // Update active nav link
            navLinks.forEach(navLink => navLink.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.nav-dropdown')) {
            document.querySelectorAll('.nav-dropdown').forEach(dropdown => {
                dropdown.classList.remove('open');
                const dropdownToggle = dropdown.querySelector('.nav-dropdown-toggle');
                if (dropdownToggle) {
                    dropdownToggle.setAttribute('aria-expanded', 'false');
                }
            });
        }
    });

    // Theme toggle
    themeToggle.addEventListener('click', function() {
        isDarkMode = !isDarkMode;
        localStorage.setItem('darkMode', isDarkMode);
        applyTheme();
    });

    // Search functionality
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        filterProducts(searchTerm);
    });

    // Cart functionality
    cartBtn.addEventListener('click', function() {
        cartSidebar.classList.add('active');
        updateCartDisplay();
    });

    cartClose.addEventListener('click', function() {
        cartSidebar.classList.remove('active');
    });

    // Close cart when clicking outside (simplified)
    document.addEventListener('click', function(event) {
        if (!cartSidebar.contains(event.target) && !cartBtn.contains(event.target)) {
            cartSidebar.classList.remove('active');
        }
    });

    // Category links
    categoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const category = this.getAttribute('data-category');
            filterButtons.forEach(btn => {
                if (btn.getAttribute('data-filter') === category) {
                    btn.click();
                } else if (category === 'implant' && btn.getAttribute('data-filter') === 'all') {
                    btn.click();
                }
            });

            // Scroll to products section
            document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Product filters
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Update active filter button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            // Filter products
            currentFilter = this.getAttribute('data-filter');
            filterProducts();
        });
    });

    // Contact form validation
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const message = document.getElementById('message');
        const nameError = document.getElementById('nameError');
        const emailError = document.getElementById('emailError');
        const messageError = document.getElementById('messageError');

        let isValid = true;

        // Reset errors
        nameError.textContent = '';
        emailError.textContent = '';
        messageError.textContent = '';

        // Validate name
        if (!name.value.trim()) {
            nameError.textContent = 'Name is required';
            isValid = false;
        }

        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email.value.trim()) {
            emailError.textContent = 'Email is required';
            isValid = false;
        } else if (!emailRegex.test(email.value)) {
            emailError.textContent = 'Please enter a valid email address';
            isValid = false;
        }

        // Validate message
        if (!message.value.trim()) {
            messageError.textContent = 'Message is required';
            isValid = false;
        }

        if (isValid) {
            alert('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        }
    });

    // Modal close
    modalClose.addEventListener('click', function() {
        productModal.classList.remove('active');
    });

    // Close modal when clicking outside
    productModal.addEventListener('click', function(e) {
        if (e.target === productModal) {
            productModal.classList.remove('active');
        }
    });

    // Initialize theme
    function initializeTheme() {
        applyTheme();
    }

    function applyTheme() {
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        } else {
            document.body.classList.remove('dark-mode');
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
        }
    }

    // Initialize products
    function initializeProducts() {
        // Sample product data
        products = [{
                id: 1,
                name: 'Premium Dental Implant System',
                category: 'implant',
                price: 249.99,
                description: 'High-quality titanium implant system with excellent osseointegration properties.',
                brand: 'DentaPrime',
                specs: 'Titanium Grade 4, Diameter: 3.5-5.0mm, Length: 8-14mm',
                usage: 'Single tooth replacement, bridge support, implant-retained dentures'
            },
            {
                id: 2,
                name: 'Digital X-Ray System',
                category: 'equipment',
                price: 12500.00,
                description: 'Advanced digital radiography system with high-resolution imaging.',
                brand: 'OralTech',
                specs: '14-bit sensor, 0.1s exposure time, Wireless connectivity',
                usage: 'Dental diagnostics, treatment planning, progress monitoring'
            },
            {
                id: 3,
                name: 'Ergonomic Dental Chair',
                category: 'equipment',
                price: 8500.00,
                description: 'Patient comfort-focused dental chair with programmable positions.',
                brand: 'ComfortDent',
                specs: 'Weight capacity: 180kg, 5 programmable positions, LED lighting',
                usage: 'Patient positioning during dental procedures'
            },
            {
                id: 4,
                name: 'Surgical Instrument Kit',
                category: 'instruments',
                price: 899.99,
                description: 'Complete set of precision surgical instruments for implantology.',
                brand: 'PrecisionDent',
                specs: '23 instruments, Stainless steel, Autoclavable case',
                usage: 'Dental implant surgery, bone grafting, periodontal surgery'
            },
            {
                id: 5,
                name: 'LED Curing Light',
                category: 'equipment',
                price: 650.00,
                description: 'High-intensity LED curing light for composite restorations.',
                brand: 'LumaCare',
                specs: '1200 mW/cm², 8 light guides, 5 curing modes',
                usage: 'Composite curing, sealants, bonding agents'
            },
            {
                id: 6,
                name: 'Autoclave Sterilizer',
                category: 'equipment',
                price: 3200.00,
                description: 'Class B autoclave for thorough sterilization of dental instruments.',
                brand: 'SteriSafe',
                specs: '23L capacity, 4 sterilization programs, Drying function',
                usage: 'Sterilization of dental instruments and equipment'
            },
            {
                id: 7,
                name: 'Orthodontic Bracket Set',
                category: 'instruments',
                price: 450.00,
                description: 'Self-ligating ceramic brackets for aesthetic orthodontics.',
                brand: 'PrecisionDent',
                specs: '0.022 slot, Low profile, 120 brackets per set',
                usage: 'Orthodontic tooth alignment and correction'
            },
            {
                id: 8,
                name: 'Intraoral Camera',
                category: 'equipment',
                price: 2200.00,
                description: 'HD intraoral camera for detailed examination and patient education.',
                brand: 'OralTech',
                specs: '1080p resolution, 6 LED lights, Wireless',
                usage: 'Intraoral imaging, patient education, documentation'
            }
        ];

        renderProducts();
    }

    // Render products to the grid
    function renderProducts() {
        productsGrid.innerHTML = '';

        const filteredProducts = currentFilter === 'all' ?
            products :
            products.filter(product => product.category === currentFilter);

        filteredProducts.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card fade-in';
            productCard.dataset.category = product.category;

            productCard.innerHTML = `
                <div class="product-image">
                    <i class="fas ${getProductIcon(product.category)}"></i>
                </div>
                <div class="product-info">
                    <span class="product-category">${product.category.charAt(0).toUpperCase() + product.category.slice(1)}</span>
                    <h3 class="product-name">${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    <div class="product-price">$${product.price.toFixed(2)}</div>
                    <div class="product-actions">
                        <button class="product-btn product-view" data-id="${product.id}">View Details</button>
                        <button class="product-btn product-cart" data-id="${product.id}">Add to Cart</button>
                    </div>
                </div>
            `;

            productsGrid.appendChild(productCard);
        });

        // Add event listeners to product buttons
        document.querySelectorAll('.product-view').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.getAttribute('data-id'));
                openProductModal(productId);
            });
        });

        document.querySelectorAll('.product-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.getAttribute('data-id'));
                addToCart(productId);
            });
        });

        // Trigger animations for newly added products
        triggerAnimations();
    }

    // Get appropriate icon for product category
    function getProductIcon(category) {
        switch (category) {
            case 'implant':
                return 'fa-tooth';
            case 'equipment':
                return 'fa-x-ray';
            case 'instruments':
                return 'fa-tools';
            default:
                return 'fa-box';
        }
    }

    // Filter products based on search term and category
    function filterProducts(searchTerm = '') {
        const filteredProducts = products.filter(product => {
            const matchesCategory = currentFilter === 'all' || product.category === currentFilter;
            const matchesSearch = !searchTerm ||
                product.name.toLowerCase().includes(searchTerm) ||
                product.description.toLowerCase().includes(searchTerm) ||
                product.brand.toLowerCase().includes(searchTerm);

            return matchesCategory && matchesSearch;
        });

        // Update display
        const productCards = document.querySelectorAll('.product-card');
        productCards.forEach(card => {
            const productId = parseInt(card.querySelector('.product-view').getAttribute('data-id'));
            const product = products.find(p => p.id === productId);

            const shouldShow = filteredProducts.includes(product);
            card.style.display = shouldShow ? 'block' : 'none';

            if (shouldShow) {
                card.classList.add('fade-in');
            }
        });

        // Trigger animations for visible products
        setTimeout(triggerAnimations, 100);
    }

    // Open product modal
    function openProductModal(productId) {
        const product = products.find(p => p.id === productId);

        if (!product) return;

        modalBody.innerHTML = `
            <div class="modal-product">
                <div class="modal-product-image">
                    <i class="fas ${getProductIcon(product.category)}"></i>
                </div>
                <div class="modal-product-info">
                    <span class="product-category">${product.category.charAt(0).toUpperCase() + product.category.slice(1)}</span>
                    <h2>${product.name}</h2>
                    <p class="modal-description">${product.description}</p>
                    
                    <div class="modal-details">
                        <div class="detail-group">
                            <h4>Brand</h4>
                            <p>${product.brand}</p>
                        </div>
                        
                        <div class="detail-group">
                            <h4>Specifications</h4>
                            <p>${product.specs}</p>
                        </div>
                        
                        <div class="detail-group">
                            <h4>Usage / Operation</h4>
                            <p>${product.usage}</p>
                        </div>
                    </div>
                    
                    <div class="modal-actions">
                        <div class="modal-price">$${product.price.toFixed(2)}</div>
                        <button class="btn btn-primary" id="modalAddToCart" data-id="${product.id}">Add to Cart</button>
                    </div>
                </div>
            </div>
        `;

        productModal.classList.add('active');

        // Add event listener to modal add to cart button
        document.getElementById('modalAddToCart').addEventListener('click', function() {
            addToCart(productId);
            productModal.classList.remove('active');
        });
    }

    // Add product to cart
    function addToCart(productId) {
        const product = products.find(p => p.id === productId);

        if (!product) return;

        // Check if product is already in cart
        const existingItem = cart.find(item => item.id === productId);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                ...product,
                quantity: 1
            });
        }

        // Update cart count
        updateCartCount();

        // Show confirmation
        showNotification(`${product.name} added to cart`);
    }

    // Update cart count display
    function updateCartCount() {
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = totalItems;
    }

    // Update cart display in sidebar
    function updateCartDisplay() {
        cartItems.innerHTML = '';

        if (cart.length === 0) {
            cartItems.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <p>Your cart is empty</p>
                </div>
            `;
            cartTotal.textContent = '$0.00';
            return;
        }

        // Create cart items
        cart.forEach(item => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';

            cartItem.innerHTML = `
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <p>${item.brand}</p>
                    <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                </div>
                <div class="cart-item-controls">
                    <div class="cart-item-quantity">
                        <button class="quantity-btn minus" data-id="${item.id}">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn plus" data-id="${item.id}">+</button>
                    </div>
                    <button class="cart-item-remove" data-id="${item.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;

            cartItems.appendChild(cartItem);
        });

        // Calculate total
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        cartTotal.textContent = `$${total.toFixed(2)}`;

        // Add event listeners to cart controls
        document.querySelectorAll('.quantity-btn.minus').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.getAttribute('data-id'));
                updateCartItemQuantity(productId, -1);
            });
        });

        document.querySelectorAll('.quantity-btn.plus').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.getAttribute('data-id'));
                updateCartItemQuantity(productId, 1);
            });
        });

        document.querySelectorAll('.cart-item-remove').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.getAttribute('data-id'));
                removeFromCart(productId);
            });
        });
    }

    // Update cart item quantity
    function updateCartItemQuantity(productId, change) {
        const item = cart.find(item => item.id === productId);

        if (!item) return;

        item.quantity += change;

        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            updateCartCount();
            updateCartDisplay();
        }
    }

    // Remove item from cart
    function removeFromCart(productId) {
        cart = cart.filter(item => item.id !== productId);
        updateCartCount();
        updateCartDisplay();
    }

    // Show notification
    function showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;

        // Add styles
        notification.style.position = 'fixed';
        notification.style.top = '100px';
        notification.style.right = '20px';
        notification.style.backgroundColor = 'var(--accent-color)';
        notification.style.color = 'white';
        notification.style.padding = '15px 20px';
        notification.style.borderRadius = 'var(--border-radius)';
        notification.style.boxShadow = 'var(--shadow)';
        notification.style.zIndex = '3000';
        notification.style.transform = 'translateX(120%)';
        notification.style.transition = 'transform 0.3s ease';

        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 10);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.transform = 'translateX(120%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Initialize animations
    function initializeAnimations() {
        // Trigger animations on load
        setTimeout(triggerAnimations, 100);

        // Add scroll event listener for animations
        window.addEventListener('scroll', triggerAnimations);
    }

    // Trigger animations when elements come into view
    function triggerAnimations() {
        const elements = document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right');

        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementBottom = element.getBoundingClientRect().bottom;

            // Check if element is in viewport
            if (elementTop < window.innerHeight - 100 && elementBottom > 0) {
                element.classList.add('visible');
            }
        });
    }

    // Update active nav link based on scroll position
    function updateActiveNavLink() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPosition = window.pageYOffset + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }

    // Initialize animated counters
    function initializeCounters() {
        statNumbers.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count'));
            const duration = 2000; // 2 seconds
            const increment = target / (duration / 16); // 60fps

            let current = 0;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                stat.textContent = Math.floor(current);
            }, 16);
        });
    }

    // Add some CSS for modal product display
    const style = document.createElement('style');
    style.textContent = `
        .modal-product {
            display: flex;
            gap: 40px;
        }
        
        @media (max-width: 768px) {
            .modal-product {
                flex-direction: column;
            }
        }
        
        .modal-product-image {
            flex: 1;
            background-color: var(--light-gray);
            border-radius: var(--border-radius);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 300px;
        }
        
        .dark-mode .modal-product-image {
            background-color: var(--secondary-color);
        }
        
        .modal-product-image i {
            font-size: 5rem;
            color: var(--accent-color);
        }
        
        .modal-product-info {
            flex: 2;
        }
        
        .modal-product-info h2 {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 15px;
        }
        
        .dark-mode .modal-product-info h2 {
            color: var(--light-color);
        }
        
        .modal-description {
            font-size: 1.1rem;
            color: var(--gray-color);
            margin-bottom: 25px;
        }
        
        .modal-details {
            margin-bottom: 30px;
        }
        
        .detail-group {
            margin-bottom: 20px;
        }
        
        .detail-group h4 {
            font-size: 1.1rem;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        
        .dark-mode .detail-group h4 {
            color: var(--light-color);
        }
        
        .detail-group p {
            color: var(--gray-color);
            line-height: 1.6;
        }
        
        .modal-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-price {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent-color);
        }
        
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .dark-mode .cart-item {
            border-bottom-color: var(--secondary-color);
        }
        
        .cart-item:last-child {
            border-bottom: none;
        }
        
        .cart-item-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--primary-color);
        }
        
        .dark-mode .cart-item-info h4 {
            color: var(--light-color);
        }
        
        .cart-item-info p {
            font-size: 0.9rem;
            color: var(--gray-color);
            margin-bottom: 8px;
        }
        
        .cart-item-price {
            font-weight: 600;
            color: var(--accent-color);
        }
        
        .cart-item-controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .cart-item-quantity {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .quantity-btn {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: var(--light-gray);
            border: none;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            color: var(--dark-color);
            transition: var(--transition);
        }
        
        .dark-mode .quantity-btn {
            background-color: var(--secondary-color);
            color: var(--light-color);
        }
        
        .quantity-btn:hover {
            background-color: var(--accent-color);
            color: white;
        }
        
        .cart-item-remove {
            background: none;
            border: none;
            color: var(--danger-color);
            cursor: pointer;
            font-size: 1.1rem;
            transition: var(--transition);
        }
        
        .cart-item-remove:hover {
            transform: scale(1.2);
        }
    `;

    document.head.appendChild(style);
}